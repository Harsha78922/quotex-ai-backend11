from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np
import tensorflow as tf

app = Flask(__name__)
CORS(app)

# Load the trained CNN+LSTM model
model = tf.keras.models.load_model("quotex_signal_model.h5")

@app.route("/predict", methods=["POST"])
def predict_signal():
    try:
        data = request.get_json()
        ohlcv = data.get("ohlcv", [])

        if not ohlcv or len(ohlcv) < 10:
            return jsonify({"error": "Insufficient OHLCV data"})

        input_data = np.array(ohlcv).reshape(1, len(ohlcv), len(ohlcv[0]))

        prediction = model.predict(input_data)
        signal = "buy" if prediction[0][0] > 0.5 else "sell"

        return jsonify({"signal": signal})
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == "__main__":
    app.run(debug=True)
